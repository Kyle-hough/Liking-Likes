var count = 9

function add1(){
    var countElement = document.querySelector(".count")
    count++
    countElement.innerText = count + " like(s)"
}

var countOne = 12

function add2(){
    var countElement = document.querySelector(".count-one")
    countOne++
    countElement.innerText = countOne + " like(s)"
}

var countTwo = 9

function add3(){
    var countElement = document.querySelector(".count-two")
    countTwo++
    countElement.innerText = countTwo + " like(s)"
}